package com.example.SWP391_SPRING2026.Controller;

import com.example.SWP391_SPRING2026.DTO.Response.ProductComboResponseDTO;
import com.example.SWP391_SPRING2026.DTO.Response.ProductDetailResponseDTO;
import com.example.SWP391_SPRING2026.DTO.Response.PreOrderCampaignResponseDTO;
import com.example.SWP391_SPRING2026.DTO.Response.ProductResponseDTO;
import com.example.SWP391_SPRING2026.DTO.Response.ProductSearchItemDTO;
import com.example.SWP391_SPRING2026.Service.PreOrderCampaignService;
import com.example.SWP391_SPRING2026.Service.ProductComboService;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.SWP391_SPRING2026.Service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.domain.Sort;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/public/products")
@RequiredArgsConstructor
public class PublicProductController {

    private final ProductService productService;
    private final ProductComboService productComboService;
    private final PreOrderCampaignService preOrderCampaignService;

    public Page<ProductSearchItemDTO> browseProducts(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String brand,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(required = false) Boolean inStock,
            @PageableDefault(size = 20, sort = "id", direction = Sort.Direction.DESC) Pageable pageable
    ) {
        return productService.browsePublicProducts(keyword, brand, minPrice, maxPrice, inStock, pageable);
    }


    @GetMapping("/search")
    @ResponseStatus(HttpStatus.OK)
    public Page<ProductSearchItemDTO> searchProducts(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String brand,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(required = false) Boolean inStock,
            @PageableDefault(size = 20, sort = "id", direction = Sort.Direction.DESC) Pageable pageable
    ) {
        return browseProducts(keyword, brand, minPrice, maxPrice, inStock, pageable);
    }

    @GetMapping("/{id:\\d+}")
    @ResponseStatus(HttpStatus.OK)
    public ProductDetailResponseDTO getProductDetail(@PathVariable Long id) {
        return productService.getPublicProductDetails(id);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<ProductResponseDTO>> getProducts(){
        return ResponseEntity.ok(productService.getProducts());
    }

    @GetMapping("/brands")
    @ResponseStatus(HttpStatus.OK)
    public List<String> getBrands() {
        return productService.getPublicBrands();
    }


    @GetMapping("/combos/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ProductComboResponseDTO getCombo(@PathVariable Long id){
        return productComboService.getComboById(id);
    }

    @GetMapping("/combos")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Page<ProductComboResponseDTO>> getAllCombos(@RequestParam(defaultValue = "0")int page,
                                                                      @RequestParam(defaultValue = "10")int size){
        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(productComboService.getAllActiveCombos(pageable));
    }

    @GetMapping("/campaigns")
    @ResponseStatus(HttpStatus.OK)
    public List<PreOrderCampaignResponseDTO> getCampaigns() {
        return preOrderCampaignService.getAll();
    }

    @GetMapping("/campaigns/{campaignId}")
    @ResponseStatus(HttpStatus.OK)
    public PreOrderCampaignResponseDTO getCampaignById(@PathVariable Long campaignId) {
        return preOrderCampaignService.getById(campaignId);
    }
}
